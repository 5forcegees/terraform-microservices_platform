# Web Sequence Diagrams
To create a web sequence diagram:
1. Visit the [Web Sequence Diagrams](https://www.websequencediagrams.com/) website.
2. Copy the code section from the diagram you wish to generate.


title GET Statement History
### GetStatements Endpoint

note left of Client
Statement History
end note

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetStatements:requests:statement/{contractAccountId}/history
GetStatements->CassandraDB:sends:CQL_request
CassandraDB->GetStatements:returns:GQL_response
GetStatements->APIGateway:returns:response
APIGateway->Client:returns:response

note left of Client
Statement PDF
end note


Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetStatementPdf:requests:statement/{statementid}
GetStatementPdf->S3:sends:Document Request
S3->GetStatements:returns:PDF document
GetStatementPdf->APIGateway:returns:response
APIGateway->Client:returns:response

### GetPayments Endpoint

title GET /payments/{contractAccountId}
Client->APIGateway:sends:credentials
APIGateway->Client:returns:authenticationToken
Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetPayments:requests:payments/{contractAccountId}
GetPayments->CassandraDB:sends:CQL_request
CassandraDB->GetPayments:returns:GQL_response
GetPayments->APIGateway:returns:response
APIGateway->Client:returns:response


### GetCommunication Endpoint by CA
title GET Communication History by CA


note left of Client
Communication History
end note

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetCommunications:communication/{contractAccountId}/history
GetCommunications->CassandraDB:sends:CQL_request
CassandraDB->GetCommunications:returns:GQL_response
GetCommunications->APIGateway:returns:response
APIGateway->Client:returns:response

note left of Client
Communication PDF
end note


Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetCommunicationPdf:requests:communication/{communicationid}
GetCommunicationPdf->S3:sends:Document Request
S3->GetCommunicationPdf:returns:PDF document
GetCommunicationPdf->APIGateway:returns:response
APIGateway->Client:returns:response

### GetCommunication Endpoint by CA
title GET Communication History by BP


note left of Client
Communication History
end note

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetCommunications:communication/{businesspartnerid}/history
GetCommunications->CassandraDB:sends:CQL_request
CassandraDB->GetCommunications:returns:GQL_response
GetCommunications->APIGateway:returns:response
APIGateway->Client:returns:response

note left of Client
Communication PDF
end note


Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetCommunicationPdf:requests:communication/{communicationid}
GetCommunicationPdf->S3:sends:Document Request
S3->GetCommunicationPdf:returns:PDF document
GetCommunicationPdf->APIGateway:returns:response
APIGateway->Client:returns:response


### GetBudgetBilling Endpoint
title GET BudgetBilling History 

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetBudgetBilling:budget-billing/{contractAccountId}
GetBudgetBilling->CassandraDB:sends:CQL_request
CassandraDB->GetBudgetBilling:returns:GQL_response
GetBudgetBilling->APIGateway:returns:response
APIGateway->Client:returns:response


### GetPaymentArrangements Endpoint
title GET PaymentArrangements History 

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetPaymentArrangements:payment-arrangements/{contractAccountId}/history
GetPaymentArrangements->CassandraDB:sends:CQL_request
CassandraDB->GetPaymentArrangements:returns:GQL_response
GetPaymentArrangements->APIGateway:returns:response
APIGateway->Client:returns:response


### GetDeferrals Endpoint

title GET deferrals history

Client->APIGateway:sends:credentials
APIGateway->Client:returns:authenticationToken
Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetDeferrals:deferrals/{contractAccountId}/history
GetDeferrals->CassandraDB:sends:CQL_request
CassandraDB->GetDeferrals:returns:GQL_response
GetDeferrals->APIGateway:returns:response
APIGateway->Client:returns:response


### Budghet bill enrollment / unenrollment
# Web Sequence Diagrams
To create a web sequence diagram:
1. Visit the [Web Sequence Diagrams](https://www.websequencediagrams.com/) website.
2. Copy the code section from the diagram you wish to generate.


title GET Statement History
### GetStatements Endpoint

note left of Client
Statement History
end note

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetStatements:requests:statement/{contractAccountId}/history
GetStatements->CassandraDB:sends:CQL_request
CassandraDB->GetStatements:returns:GQL_response
GetStatements->APIGateway:returns:response
APIGateway->Client:returns:response

note left of Client
Statement PDF
end note


Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetStatementPdf:requests:statement/{statementid}
GetStatementPdf->S3:sends:Document Request
S3->GetStatements:returns:PDF document
GetStatementPdf->APIGateway:returns:response
APIGateway->Client:returns:response

### GetPayments Endpoint

title GET /payments/{contractAccountId}
Client->APIGateway:sends:credentials
APIGateway->Client:returns:authenticationToken
Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetPayments:requests:payments/{contractAccountId}
GetPayments->CassandraDB:sends:CQL_request
CassandraDB->GetPayments:returns:GQL_response
GetPayments->APIGateway:returns:response
APIGateway->Client:returns:response


### GetCommunication Endpoint by CA
title GET Communication History by CA


note left of Client
Communication History
end note

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetCommunications:communication/{contractAccountId}/history
GetCommunications->CassandraDB:sends:CQL_request
CassandraDB->GetCommunications:returns:GQL_response
GetCommunications->APIGateway:returns:response
APIGateway->Client:returns:response

note left of Client
Communication PDF
end note


Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetCommunicationPdf:requests:communication/{communicationid}
GetCommunicationPdf->S3:sends:Document Request
S3->GetCommunicationPdf:returns:PDF document
GetCommunicationPdf->APIGateway:returns:response
APIGateway->Client:returns:response

### GetCommunication Endpoint by CA
title GET Communication History by BP


note left of Client
Communication History
end note

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetCommunications:communication/{businesspartnerid}/history
GetCommunications->CassandraDB:sends:CQL_request
CassandraDB->GetCommunications:returns:GQL_response
GetCommunications->APIGateway:returns:response
APIGateway->Client:returns:response

note left of Client
Communication PDF
end note


Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetCommunicationPdf:requests:communication/{communicationid}
GetCommunicationPdf->S3:sends:Document Request
S3->GetCommunicationPdf:returns:PDF document
GetCommunicationPdf->APIGateway:returns:response
APIGateway->Client:returns:response


### GetBudgetBilling Endpoint
title GET BudgetBilling History 

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetBudgetBilling:budget-billing/{contractAccountId}
GetBudgetBilling->CassandraDB:sends:CQL_request
CassandraDB->GetBudgetBilling:returns:GQL_response
GetBudgetBilling->APIGateway:returns:response
APIGateway->Client:returns:response


### GetPaymentArrangements Endpoint
title GET PaymentArrangements History 

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetPaymentArrangements:payment-arrangements/{contractAccountId}/history
GetPaymentArrangements->CassandraDB:sends:CQL_request
CassandraDB->GetPaymentArrangements:returns:GQL_response
GetPaymentArrangements->APIGateway:returns:response
APIGateway->Client:returns:response


### GetDeferrals Endpoint

title GET deferrals history

Client->APIGateway:sends:credentials
APIGateway->Client:returns:authenticationToken
Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->GetDeferrals:deferrals/{contractAccountId}/history
GetDeferrals->CassandraDB:sends:CQL_request
CassandraDB->GetDeferrals:returns:GQL_response
GetDeferrals->APIGateway:returns:response
APIGateway->Client:returns:response


### Budget bill enrollment / unenrollment
title Budget Bill


note left of Client 
Budget Bill Enroll Eligibilty
end note

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->BudgetBill:budgetbill/{contractaccountid}/enroll/eligibility
BudgetBill->MCF:sends:oData Request to check eligibilty
MCF->BudgetBill:returns:odata_response
BudgetBill->APIGateway:returns:response
APIGateway->Client:returns:response

note left of Client 
Budget Bill Enroll 
end note

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->BudgetBill:budgetbill/{contractaccountid}/enroll
BudgetBill->MCF:sends:oData Request to enroll
MCF->BudgetBill:returns:odata_response
BudgetBill->APIGateway:returns:response
APIGateway->Client:returns:response

note left of Client
Budget Bill Unenroll Eligibilty
end note

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->BudgetBill:budgetbill/{contractaccountid}/unenroll/eligibility
BudgetBill->MCF:sends:oData Request to check eligibilty
MCF->BudgetBill:returns:odata_response
BudgetBill->APIGateway:returns:response
APIGateway->Client:returns:response

note left of Client 
Budget Bill Unroll 
end note

Client->APIGateway:sends:authenticatedRequest
APIGateway->APIGateway:authorizesRequest
APIGateway->BudgetBill:budgetbill/{contractaccountid}/unenroll
BudgetBill->MCF:sends:oData Request to enroll
MCF->BudgetBill:returns:odata_response
BudgetBill->APIGateway:returns:response
APIGateway->Client:returns:response

