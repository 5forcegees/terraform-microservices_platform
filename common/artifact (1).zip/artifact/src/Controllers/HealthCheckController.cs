﻿using Microsoft.AspNetCore.Mvc;

namespace SwaggerUI.Web.Controllers
{
    [Route("healthcheck")]
    public class HealthCheckController : Controller
    {
        [Route("")]
        public IActionResult Get()
        {
            return Ok();
        }
    }
}
