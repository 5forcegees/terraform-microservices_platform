﻿using Newtonsoft.Json;

namespace SwaggerUI.Web.Models
{
    public class SwaggerDocInfoModel
    {
        [JsonProperty("url")]
        public string FilePath { get; set; }
        [JsonProperty("name")]
        public string Name { get; set; }
    }
}
