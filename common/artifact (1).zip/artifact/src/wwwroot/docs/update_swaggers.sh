env='dev2'
aws ssm get-parameters --names "/CI/MS/${env}/ALB_URL" 

#get the /CI/MS/poc/ALB_URL from parameter store, grep for the "Value" line, strip off everything but the value, and remove the 'http://' on the url 
alb_url=`aws ssm get-parameters --names "/CI/MS/${env}/ALB_URL" | grep Value | sed -e "s?            \"Value\": \"??" | sed -e 's?"$??' `

#verify that we got a parameter
if [ "${alb_url}" = "" ]; then
    echo "No /CI/MS/${env}/ALB_URL retrieved from parameter store"
    exit 1
fi


for i in $(echo account address authentication budget-bill customer deferral device document forms installment notification outage payment project ); do echo $i && curl http://${alb_url}/swagger/$i/v1.0/swagger.json > $i/swagger.json ; done
