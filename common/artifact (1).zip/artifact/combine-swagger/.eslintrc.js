module.exports = {
  "extends": "airbnb-base",
  "rules": {
    "no-param-reassign": 0,
    "prefer-destructuring": 0
  }
};
