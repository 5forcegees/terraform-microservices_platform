const fs = require('fs');
const outputAWSSwaggerName = 'combinedAWSSwagger.json'; //  name of swagger file to be created
const outputSwaggerName = 'combinedSwagger.json'; //  name of swagger file to be created

var Promise = require("bluebird");
var fsPromise = Promise.promisifyAll(require("fs"));

//  services whose swaggers will be combined
const services = [
  'account',
  'address',
  'authentication',
  'budget-bill',
  'customer',
  'deferral',
  'device',
  'document',
  'forms',
  'installment',
  'notification',
  'outage',
  'payment',
  'project',
  'statement',
];

//  return AWS swagger extension to proxy traffic to lambda
function awsIntegration() {
  return {
    responses: {
      default: {
        statusCode: '200',
      },
    },
    uri: '$LAMBDA_PROXY',
    passthroughBehavior: 'when_no_match',
    httpMethod: 'POST',
    contentHandling: 'CONVERT_TO_TEXT',
    type: 'aws_proxy',
  };
}

function awsSecurityDefinitions() {
  return {
    ciCognitoAuth: {
      type: 'apiKey',
      name: 'Authorization',
      in: 'header',
      'x-amazon-apigateway-authtype': 'cognito_user_pools',
      'x-amazon-apigateway-authorizer': {
        providerARNs: [
          '$COGNITO_ID',
        ],
        type: 'cognito_user_pools',
      },
    },
    api_key: {
      type: 'apiKey',
      name: 'x-api-key',
      in: 'header',
    },
  };
}

//  create initial, shell swagger file
function initSwagger() {
  return {
    swagger: '2.0',
    info: {
      title: 'ci-$ENV-apigw',
      description: 'CI API Gateway',
      version: '1.0.0',
    },
    'x-amazon-apigateway-binary-media-types': [ "application/pdf" ],
    schemes: [ 'https', ],
    paths: {
      '/{version}/{proxy+}': {
        'x-amazon-apigateway-any-method': {
          responses: {},
          security: [
          {
            api_key: [],
          },
          {
            ciCognitoAuth: [],
          },
          ],
          'x-amazon-apigateway-integration': {
            uri: '$LAMBDA_PROXY',
            passthroughBehavior: 'when_no_match',
            httpMethod: 'POST',
            type: 'aws_proxy',
          },
        },
      },
			"/{version}/private": {
				"x-amazon-apigateway-any-method": {
					"consumes": [
						"application/json"
					],
					"parameters": [
						{
							"name": "version",
							"in": "path",
							"required": true,
							"type": "string"
						}
					],
					"responses": {
						"404": {
							"description": "404 response"
						}
					},
					"x-amazon-apigateway-integration": {
						"responses": {
							"default": {
								"statusCode": "404"
							}
						},
						"requestTemplates": {
							"application/json": "{\"statusCode\": 200}"
						},
						"passthroughBehavior": "when_no_match",
						"type": "mock"
					}
				}
			},
			"/{version}/private/{proxy+}": {
				"x-amazon-apigateway-any-method": {
					"produces": [
						"application/json"
					],
					"parameters": [
						{
							"name": "version",
							"in": "path",
							"required": true,
							"type": "string"
						},
						{
							"name": "proxy",
							"in": "path",
							"required": true,
							"type": "string"
						}
					],
					"responses": {},
					"x-amazon-apigateway-integration": {
						"uri": "$LAMBDA_PRIVATE",
						"responses": {
							"default": {
								"statusCode": "200"
							}
						},
						"passthroughBehavior": "when_no_match",
						"httpMethod": "POST",
						"contentHandling": "CONVERT_TO_TEXT",
						"type": "aws_proxy"
					}
				}
      },
      "/{version}/general-information": {
        "get": {
          "responses": {
            "200": {
              "description": "200 response"
            }
          },
          "x-amazon-apigateway-integration": {
            "requestTemplates": {
              "application/json": "{\"statusCode\":200}"
            },
            "responses": {
              "200": {
                "statusCode": "200",
                "responseTemplates": {
                  "application/json": "{\"minSupportedVersion\": {\"android\": \"3.2.0\",\"iOS\": \"2.2.0\"},\"redirectApp\":\"false\",\"redirectMessage\": \"We’re in the process of improving our app. This version of the app is currently unavailable – we’re sorry for any inconvenience. For now, please use our new mobile website, and come back soon for an updated app experience.\",\"redirectUrl\": \"https://pse.com/\"}"
                }
              }
            },
            "passthroughBehavior": "when_no_match",
            "type": "mock"
          }
        }
      }
    },
    definitions: {},
  };
}

function getSourceSwaggerFiles(svcs) {
  return Promise.map(svcs, function(service) {
    return fs.readFileAsync("../src/wwwroot/docs/"+service+"/swagger.json", 'utf-8')
      .then(function(fileContents){
        if (fileContents.indexOf("HTML") > -1 || fileContents.length === 0){
          console.log("found a problem with the swagger file for  "+ service); 
          console.log("Here's the file: ", fileContents);
        }
        return JSON.parse(fileContents.replace(/^\uFEFF/, ''));
      });
  }).then(function(resultArray){
      return resultArray;
  }).catch(function(err){
    console.log("There was an error processing a swagger file.  Are you sure the swagger endpoint is available for all the services?\nHere's the err:", err);
  })
}

//  read in swagger files from repo and create a combined swagger file compatible with AWS API GW
function combineSwagger(svcs, outputName, outputAWSName) {
  const outAWSSwagger = initSwagger();
  outAWSSwagger.securityDefinitions = awsSecurityDefinitions();

  getSourceSwaggerFiles(svcs).then(function(swaggers){
    swaggers.forEach((swaggerObj) => {
      Object.keys(swaggerObj.definitions).forEach((definition) => {
        //  set all the readOnly property definitions to false because true breaks aws swagger upload
        const properties = swaggerObj.definitions[definition].properties;
        if (properties) {
          Object.keys(properties).forEach((property) => {
            const cleanPropertyName = property.replace(/[^a-zA-Z0-9]*/g, '');
            // remove non alphanumeric characters from definition names because they break aws import
            if (cleanPropertyName !== property) {
              swaggerObj.definitions[definition].properties[cleanPropertyName] =
                swaggerObj.definitions[definition].properties[property];

              delete swaggerObj.definitions[definition].properties[property];
            }
          });
          Object.keys(properties).forEach((property) => {
            const attributes = swaggerObj.definitions[definition].properties[property];
            if (attributes) {
              Object.keys(attributes).forEach((attribute) => {
                if (attribute === 'readOnly') {
                  swaggerObj.definitions[definition].properties[property][attribute] = false;
                }
              });
            }
          });
        }
      });

      //  loop over the paths,
      //  if it's an anonymous call, push it into the outAWSSwagger objects
      Object.keys(swaggerObj.paths).forEach((path) => {
        //  keep track of this path's Anonymity
        let pathHasAnonymous = false;

        Object.keys(swaggerObj.paths[path]).forEach((method) => {
          //  keep track of this method's Anonymity
          let isAnonymous = false;

          const parameters = swaggerObj.paths[path][method].parameters;
          if (parameters) {
            //  if it's the first loop then we have to initialize the path in the output objects
            if (!outAWSSwagger.paths[path]) {
              outAWSSwagger.paths[path] = JSON.parse(JSON.stringify(swaggerObj.paths[path]));
            }

            //  loop over the parameters
            parameters.forEach((param) => {
              //  set the anonymous flag
              if (param.name === 'Authorization' && param.in === 'header' && !param.required) {
                isAnonymous = true;
                pathHasAnonymous = true;
              }
            });
            //  if it's not anonymous, we don't want that method, delete it if it's there
            if (!isAnonymous) {
              if (outAWSSwagger.paths[path][method]) {
                delete outAWSSwagger.paths[path][method]; //  this remove api that require JWT
              }
            } else {
              //  it's anonymous, add the needed aws swagger stuff
              //  add API Key check on every method
              outAWSSwagger.paths[path][method].security = [
              { api_key: [] },
              ];

              //  add aws lambda proxy integration
              outAWSSwagger.paths[path][method]['x-amazon-apigateway-integration'] = awsIntegration();

              Object.keys(swaggerObj.definitions).forEach((definition) => {
                outAWSSwagger.definitions[definition] = swaggerObj.definitions[definition];
              });
            }
          } else {
            // console.log('no parameters found for path:method '+path+' : '+method);
          }
        });

        if (!pathHasAnonymous) {
          //  this path doesn't have any anon methods, remove it from the output object
          if (outAWSSwagger.paths[path]) {
            delete outAWSSwagger.paths[path];
          }
        }
      });
    });

    fs.writeFileSync(outputAWSName, JSON.stringify(outAWSSwagger), 'utf8');
  })
}

//  combine swagger from each MS repo into a single AWS API GW-compliant file
combineSwagger(services, outputSwaggerName, outputAWSSwaggerName);

