# combine-swagger
- Standalone node script that combines the swagger files found in this repo's /src/wwwroot/docs/*
- Also injects AWS extensions to enable authentication, api key, and entry into AWS network

# to run and test the script locally
# NOTE: this will not actually make the gateway work for making API requests, this is only to verify that there are no breaking errors in the swagger syntax
1. npm start
2. shell.sh
3. aws apigateway put-rest-api --region us-west-2 --body file://combinedAWSSwagger.json --mode overwrite --rest-api-id exptunvrcj
  - review the output to ensure no breaking error

#Initial setup of gateway:
1. cd documentation/src/wwwroot/docs
2. vi update_swaggers.sh
  - set the env variable for the desired environment (this will pull the current swagger.json files from the ALB endpoint)
3. sh update_swaggers.sh
  - verify that all the swagger.json files in the service directories (account/swagger.json, authentication/swagger.json, etc) are not empty
  - This command will show you the line count for each file: for i in $(find -name swagger.json); do wc -l $i ; done
4. cd into the combine_swagger dir
5. run the script: npm start
6. update the shell.sh script with the correct values
  - for instance, the LAMBDA_PROXY should have the ARN for the environment's lambda proxy function 
7. run the shell.sh script  
  - this will replace the placeholder variables (such as LAMBDA_PROXY) with the correct values and then attempt to push the swagger file up to AWS
  - if the push to AWS fails then review the errors and see if you can correct them
