########################
#environment specific variables
env='script_test'
terraform_s3_bucket='ci-nonprod-tfstate'
gw_id='exptunvrcj'
lambda_proxy='arn:aws:apigateway:us-west-2:lambda:path/2015-03-31/functions/arn:aws:lambda:us-west-2:484054947536:function:ci-dev2-apigw-proxy/invocations'
lambda_private='arn:aws:apigateway:us-west-2:lambda:path/2015-03-31/functions/arn:aws:lambda:us-west-2:484054947536:function:ci-private-404/invocations'
lambda_az='arn:aws:apigateway:us-west-2:lambda:path/2015-03-31/functions/arn:aws:lambda:us-west-2:484054947536:function:ci-dev2-apigw-cognito-custom-auth/invocations'
cognito_id='arn:aws:cognito-idp:us-west-2:484054947536:userpool/us-west-2_tvx9jhjOp'
region='us-west-2'
########################

sed -i 's,$ENV,'${env}',g' combinedAWSSwagger.json
sed -i 's,$LAMBDA_AUTHORIZER,'${lambda_az}',g' combinedAWSSwagger.json
sed -i 's,$LAMBDA_PROXY,'${lambda_proxy}',g' combinedAWSSwagger.json
sed -i 's,$LAMBDA_PRIVATE,'${lambda_private}',g' combinedAWSSwagger.json
sed -i 's,$COGNITO_ID,'${cognito_id}',g' combinedAWSSwagger.json
sed -i 's,/v{version}/,/{version}/,g' combinedAWSSwagger.json
#TODO: ask the devs to update the customer swagger to not use brackets in the swagger for McfList[IdentifierModel]
sed -i 's,McfList\[IdentifierModel\],McfListIdentifierModel,g' combinedAWSSwagger.json
