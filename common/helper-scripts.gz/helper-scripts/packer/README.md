# Packer
## Intro
- Packer is a tool used to build images: [Docs](https://www.packer.io/intro/index.html)
- We will use packer to create EBS-backed AMI
- 
