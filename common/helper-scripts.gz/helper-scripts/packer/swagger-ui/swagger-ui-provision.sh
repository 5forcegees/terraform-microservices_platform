#!/usr/bin/env bash
set -ex

# declare services array containing name of each service
services='["account-history","cognito"]'

cd ~

# install apache and make it start at system boot
sudo yum update -y
sudo yum install -y httpd24
sudo chkconfig httpd on

# install json script thing
sudo yum install -y jq

# install git
sudo yum install -y git

# allow ec2-user to modify/write to apache dir
sudo usermod -a -G apache ec2-user
sudo su - $USER #pick up new permissions
sudo chown -R ec2-user:apache /var/www
sudo chmod 2775 /var/www
find /var/www -type d -exec sudo chmod 2775 {} \;
find /var/www -type f -exec sudo chmod 0664 {} \;

# clone swagger ui and move web component to apache
git clone https://github.com/swagger-api/swagger-ui.git
mv ./swagger-ui/dist/* /var/www/html

# create services.js file that contains a JSON array listing services and local url to spec
# first, just parse services var to validate input and allow script to error out if it isn't
jq -n -s --argjson argslist $services '$argslist[]'
# parse again and this time create JSON and save into services.js
jq -n -s --argjson argslist $services '$argslist[]' | jq -n 'reduce inputs as $row ([]; . + [{"url": ("docs/" + $row + ".json"), name: $row}])' > services.js
# modify first line of services.js file to set JSON array to a variable
sed -i "1s/.*/var apis=[/" services.js
mv services.js /var/www/html

# modify index.html to use the previously set `apis` variable for swagger files: https://github.com/swagger-api/swagger-ui/pull/3261#issuecomment-309579253
cd /var/www/html
mkdir docs
sed -i 's/<script>/<script src=\".\/services.js\"> <\/script>'$'\\n<script>/' index.html
sed -i 's/url:.*/urls: apis,/' index.html
