const AWS = require('aws-sdk');
const util = require('util');
const fs = require('fs');

// the region isn't getting picked up from the global config, set it here
AWS.config.update({region:'us-west-2'});
const ecs = new AWS.ECS();
const cloudwatch = new AWS.CloudWatch()
const elb = new AWS.ELBv2();
//

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

//Modify this line in order to deploy alternate environments
var environment = 'dev2'

var dashboard_name = 'Microservices_Monitor_'+environment;
var cluster_name = 'ci-'+environment+'-cluster';
var alb_arn;
var alb_metrics = [];
var mem_metrics = [];
var cpu_metrics =[];
var dashboardDefinition;
var nest_count = 1;
var dashboard_set = 0;

function getServices(params) {
    ecs.listServices(params, function(err, data) {
        if (err) {
            console.log(err, err.stack); // an error occurred
        }
        else {
            if (data.hasOwnProperty('nextToken')) {
                nest_count++;
                params.nextToken = data.nextToken;     
                getServiceDetails({services: data.serviceArns, cluster: params.cluster});
                getServices(params);
            } else {
                //Iterated to Receive Service List, now iterate to get details
                getServiceDetails({services: data.serviceArns, cluster: params.cluster});
             }   
        }
      });


    nest_count--;
    console.log('Waiting 5 seconds for functions');
    setTimeout(function(){ 
        if(nest_count<=0 && dashboard_set == 0) {
            //Ensure that dashboard is only refreshed once    
            dashboard_set = 1;
            compileDashboard();
        }  
    }, 5000);
}

function getServiceDetails(service_params) {
    var albName;
    ecs.describeServices(service_params, function(err, data) {
      if (err) {
          console.log(err, err.stack); // an error occurred
      }
      else {
          if (data.nextToken) {
            data.services.forEach(function(service){
                if(service.loadBalancers.length==0){
                    console.log(service.serviceName+' does not have any associated target groups.')
                }
                else {
                    var targetGroupArnArr = '';
                    targetGroupArnArr = service.loadBalancers[0].targetGroupArn.split(":");
                    var targetGroupName = '';
                    targetGroupName = targetGroupArnArr[targetGroupArnArr.length - 1]
                    var tg_params = {
                        TargetGroupArns: [ service.loadBalancers[0].targetGroupArn ]
                    };
                    elb.describeTargetGroups(tg_params, function(err, data) {
                        if (err){
                            console.log(err, err.stack); // an error occurred
                        }
                        else {
                            var albArnArr = data.TargetGroups[0].LoadBalancerArns[0].split(":");  
                            albName = albArnArr[albArnArr.length - 1]; 
                        }
                        
                    });
                    setTimeout(function(){ alb_metrics.push(["AWS/ApplicationELB","HealthyHostCount","TargetGroup",targetGroupName,"LoadBalancer",albName.replace("loadbalancer/",""),{"stat":"Minimum","label":service.serviceName}])}, 800);
                }
                mem_metrics.push(["AWS/ECS","MemoryUtilization","ServiceName",service.serviceName,"ClusterName",cluster_name,{"stat":"Maximum","period":60}])
                cpu_metrics.push(["AWS/ECS","CPUUtilization","ServiceName",service.serviceName,"ClusterName",cluster_name,{"stat":"Maximum","period":60}])
            }); 

              service_params.nextToken = data.nextToken;
               getServiceDetails(service_params);
          } else {
              //Iterated to Receive Service Details List, now iterate to parse distinct services and target groups
                data.services.forEach(function(service){
                    if(service.loadBalancers.length==0){
                        console.log(service.serviceName+' does not have any associated target groups.')
                    }
                    else {
                        var targetGroupArnArr = '';
                        targetGroupArnArr = service.loadBalancers[0].targetGroupArn.split(":");
                        var targetGroupName = '';
                        targetGroupName = targetGroupArnArr[targetGroupArnArr.length - 1]
                        var tg_params = {
                            TargetGroupArns: [ service.loadBalancers[0].targetGroupArn ]
                        };
                        elb.describeTargetGroups(tg_params, function(err, data) {
                            if (err){
                                console.log(err, err.stack); // an error occurred
                            }
                            else {
                                var albArnArr = data.TargetGroups[0].LoadBalancerArns[0].split(":");  
                                albName = albArnArr[albArnArr.length - 1]; 
                            }
                            
                        });
                        setTimeout(function(){ alb_metrics.push(["AWS/ApplicationELB","HealthyHostCount","TargetGroup",targetGroupName,"LoadBalancer",albName.replace("loadbalancer/",""),{"stat":"Minimum","label":service.serviceName}])}, 800);
                    }
                    mem_metrics.push(["AWS/ECS","MemoryUtilization","ServiceName",service.serviceName,"ClusterName",cluster_name,{"stat":"Maximum","period":60}])
                    cpu_metrics.push(["AWS/ECS","CPUUtilization","ServiceName",service.serviceName,"ClusterName",cluster_name,{"stat":"Maximum","period":60}])
                }); 
           }   
      }  
    });
    nest_count--;
}

function compileDashboard() {
    dashboardDefinition = {
        "widgets": [
            {
                "type":"metric",
                "x":0, "y":0,
                "width":24, "height":6,
                "properties": {
                    "view": "timeSeries",
                    "stacked":true,
                    "metrics": alb_metrics,
                    "region":"us-west-2",
                    "start":"-P3D","end":"P0D",
                    "title":"Container Count (Healthy ELB Targets) - "+environment
                }
            },
            {
                "type":"metric",
                "x":0, "y":0,
                "width":24, "height":6,
                "properties": {
                    "view": "timeSeries",
                    "stacked":false,
                    "metrics": mem_metrics,
                    "region":"us-west-2",
                    "start":"-P3D","end":"P0D",
                    "title":"Maximum Memory Utilization - "+environment
                }
            },
            {
                "type":"metric",
                "x":0, "y":0,
                "width":24, "height":6,
                "properties": {
                    "view": "timeSeries",
                    "stacked":false,
                    "metrics": cpu_metrics,
                    "region":"us-west-2",
                    "start":"-P3D","end":"P0D",
                    "title":"Maximum CPU Utilization - "+environment
                }
            }
        ]
    }
    var dashboard_params = {
        DashboardBody: JSON.stringify(dashboardDefinition),
        DashboardName: dashboard_name
      };
      cloudwatch.putDashboard(dashboard_params, function(err, data) {
        if (err) console.log(err, err.stack); // an error occurred
        else     console.log(data);           // successful response
      });

}

getServices({cluster: cluster_name, launchType: 'FARGATE'});
