// below produce apis that does not require JWT in the request.
// Use this to provision rest api in aws api gateway.
// use proxy+ with Cognito Authorizer for all secure APIs.

var fs = require('fs');
var swagger = "authentication.json"; // get this from the json link on alb.com/swagger/authentication

var swaggerObj = JSON.parse(fs.readFileSync(swagger, 'utf8'));

//console.log (swaggerObj.paths);

Object.keys(swaggerObj.paths).forEach(function(path) {
    Object.keys(swaggerObj.paths[path]).forEach(function(method) {
        var isAnonymous = false;
        var parameters = swaggerObj.paths[path][method].parameters;
        parameters.forEach(function(param) {
            if(param.name == "Authorization" && param.in == "header" && !param.required )
                isAnonymous = true;
        });
        
        if(!isAnonymous) {
            //remove APIs require JWT
            delete swaggerObj.paths[path][method]
            //if there is no method under this path, remove the path itself.
            if(Object.keys(swaggerObj.paths[path]).length === 0 && swaggerObj.paths[path].constructor === Object)
                delete swaggerObj.paths[path];
        }
    });
});

fs.writeFile('./white-listed.json', JSON.stringify(swaggerObj, null, 2) , 'utf-8');

console.log('done');