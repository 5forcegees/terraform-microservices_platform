# swap-profile
Helper script to easily swap AWS profiles

## Introduction
- All commands performed with AWS CLI must be authenticated
- If AWS Credentials are not passed in manually or found in the shell environment, the CLI automatically loads creds from the `~/.aws/credentials` file
- This credential file lists AWS key/secrets in the following format:

```
[default]
aws_access_key_id = AKIA***
aws_secret_access_key = abc***

[profile1]
aws_access_key_id = AKIA***
aws_secret_access_key = in6***

[profile2]
aws_access_key_id = AKIA***
aws_secret_access_key = 123***
```

- each of the sections(separated by `[]` ) corresponds to a different **profile** that may be pointing to the same or different AWS accounts
- By default, the AWS CLI will use the credentials found under the `[default]` profile
  - To use any other profile, must either pass the `--profile <profile>` flag as part of the command, or set the `AWS_PROFILE=<profile>` environment variable

## Functionality
- This script provides an alternative approach to swapping profiles
- It takes in a profile name, reads the existing key/secret associated to that profile, and then overwrites the `default` key/secret with the profile's values
- In addition, the script also supports using a configured profile's credentials to assume another role, and updates the default profile with the assumed role's key/secret/session_token
- The script currently assumes there is a 1:1 mapping between a profile and the role it can assume, and this mapping is set in the `config.json`

## PreRequisite
1. Install Python and AWS CLI
2. Setup `~/.aws/credentials`
3. Setup the `config.json` if planning on assuming a role
  - To assume role with a profile, the profile name must exist in the config.json
  - e.g. if you have a `[personal]` profile, the `config.json` must contain:

``` js
{
  ...
   "personal": {
      "role_arn": "***"
   }
  ...
}
```
## Usage
1. python swap-profile.py [profile] [--assume]
- Examples:
  - To just swap profiles, run `python swap-profile pse-dev`
  - To use a profile to assume a role, run `python swap-profile pse-dev --assume`

## WARNING
1. Script takes a backup of the creds file as `~/.aws/credenials.bkp` **ONLY** if `~/.aws/credenials.bkp` does not already exist
2. Does not touch `~/.aws/config` file
