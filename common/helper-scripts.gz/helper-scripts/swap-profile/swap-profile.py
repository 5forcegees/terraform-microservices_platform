import subprocess
import os
import sys
import json
import argparse
import ConfigParser
import unicodedata
from shutil import copyfile

Config = ConfigParser.ConfigParser()
Config.read(os.path.expanduser('~/.aws/credentials'))

def updateCredFile(key, secret, session_token=None):
    Config.set("default", "aws_access_key_id", key)
    Config.set("default", "aws_secret_access_key", secret)
    if session_token is not None:
        Config.set("default", 'aws_session_token', session_token)
    else:
        Config.remove_option("default", 'aws_session_token')
    with open(os.path.expanduser('~/.aws/credentials'), 'wb') as configfile:
        Config.write(configfile)

def getProfileCreds(profile):
    return (Config.get(profile, "aws_access_key_id"), Config.get(profile, "aws_secret_access_key"))

def assumeRole(profile):
    with open('config.json') as json_data:
        json_config = json.load(json_data)
        role = json_config[profile]["role_arn"]

    cmd = "aws sts assume-role --role-arn %s --role-session-name pse-assumed-role --profile %s" % (role, profile)
    print cmd
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out, err = proc.communicate()
    json_output = json.loads(out)
    return (json_output["Credentials"]["AccessKeyId"], json_output["Credentials"]["SecretAccessKey"], json_output["Credentials"]["SessionToken"], role)

def backupCreds():
    aws_creds_file = os.path.expanduser("~/.aws/credentials")
    aws_creds_file_bkp = os.path.expanduser("~/.aws/credentials.bkp")

    if not os.path.isfile(aws_creds_file_bkp):
        print "creating backup file: " + aws_creds_file_bkp
        copyfile(aws_creds_file, aws_creds_file_bkp)
    else:
        print "skipping backup creation as " + aws_creds_file_bkp + " exists"

def validateInput(args):
    parser = argparse.ArgumentParser()
    parser.add_argument("profile", help="profile to set as default in aws cred file")
    parser.add_argument("--assume", help="flag to use profile to assume role, as defined in config.json", action="store_true")
    return parser.parse_args()

def main():
    args = validateInput(sys.argv)
    backupCreds()
    if args.assume:
        (key, secret, session_token, role) = assumeRole(args.profile)
        updateCredFile(key, secret, session_token)
        print "Set default AWS profile to assumed role: " + role
    else:
        (key, secret) = getProfileCreds(args.profile)
        updateCredFile(key, secret)
        print "Set default AWS profile to: " + args.profile

if __name__ == "__main__":
    main()
