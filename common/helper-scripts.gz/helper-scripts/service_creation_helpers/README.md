add_task_definitions.js is a node script used when standing up new services in an environment

The terraform scripts we use to stand up new services: (terraform/setup_application_services ) does not handle the creation of the required task definitions.  This script fills that gap by pulling the array of services out of the terraform/setup_application_services/<env>/<env>.auto.tfvars file, checking for a matching task definition for each service, and registering a placeholder task definition for any service that doesn't have one.  


