'use strict';
const args = require('yargs').argv;

var requiredArgs = ['environment', 'tfvarsFilePath'];

// check for the required arguments or for the --help flag, print usage statement and exit if missing required args or --help is passed 
const usageString = '\nUsage: node add_task_definitions.js --environment=<env> --tfvarsFilePath=<absolute path to tfvars file for env>\nExample:  node add_task_defninitions.js --environment=poc --tfvarsFilePath=/data/code/terraform/setup_application_services/poc/poc.auto.tfvars \n';
requiredArgs.forEach(function(requiredArgName){
    if (!args[requiredArgName] || args.help){
        console.log(usageString);
        process.exit();
    }   
});

const fs = require('fs');
const AWS = require('aws-sdk');

// for some reason the region isn't getting picked up from the global config, set it here
AWS.config.update({region:'us-west-2'});
const ecs = new AWS.ECS();

// read in the tfvars file
var lineReader = require('readline').createInterface({
    input: require('fs').createReadStream(args['tfvarsFilePath'])
});

// set the regex for the service_names line in the file
var searchPattern = new RegExp('^service_names = ');
var array = [];
// read through the file to find the matching line
lineReader.on('line', function (line) {
    if (searchPattern.test(line)) {
        // the matching line was found, parse the rest of the line as JSON (handles arrays too)
        try {
            array = JSON.parse( line.replace("service_names = ",""));
        } catch(err){
            process.exit("could not parse service names from line: ", line);
        }
    }
}).on('close', function(){
    // finished parsing the file
    if (array.length > 0){
        // we have entries in the service_names array
        array.forEach(function(serviceName){
//            console.log('looping over serviceName ', serviceName);
            var params = {
                taskDefinition: serviceName+'-'+args['environment']
            };
            // check if there's a matching task definition in aws already
            ecs.describeTaskDefinition(params, function(err, data) {
                if (err) {
                    console.log('ecs.describeTaskDefinition err: ', err);
                    // if we get this error message then the task definition doesn't exist, we'll create and push a generic one
                    if (err.message == 'Unable to describe task definition.'){
                        // the task definition was not found, register the dummy definition so the service can be created

                        // read in the dummy task definition file
                        fs.readFile("task-definition.json", {encoding: 'utf-8'}, function(err, helloWorldTaskDefinition){
                            if (err){
                                console.log("got err on fs.readFile(\"task-definition.json\": ", err);
                            }
                            try{
                                // parse it as JSON
                                helloWorldTaskDefinition = JSON.parse(helloWorldTaskDefinition);
                            } catch(err){
                                console.log("err parsing task definition as JSON: ", err);
                                process.exit("could not parse task definition file");
                            }

                            // update the family and name
                            helloWorldTaskDefinition.family = serviceName+'-'+args['environment'];
                            helloWorldTaskDefinition.containerDefinitions[0].name = serviceName;

                            // register the task def
                            console.log("registering task definition: ", helloWorldTaskDefinition);
                            ecs.registerTaskDefinition(helloWorldTaskDefinition,  function(err, registerTaskDefinitionResponse) {
                                if (err){
                                    console.log('err: ',err);
                                } else {
                                    console.log('task definition registered!  \nresponse: ', registerTaskDefinitionResponse);
                                }
                            });
                        })

                    } else {
                        process.exit(' exiting due to unhandled error: ', err);
                    }
                }   else  {   
                    //                    console.log(data);           // successful response
                    console.log('the task '+ serviceName+'-'+args['environment'] +' definition was found, no further action is required for service: ' + serviceName);
                }
            });
        });
    } else {
        process.exit("no services names found in array ", array);
    }
});


/**
// decided to use generic task definition from a flat file instead of from aws so taking this out
params = {  taskDefinition: 'hello-world'   };
console.log('using params: ', params);

ecs.describeTaskDefinition(params, function(err, helloWorldTaskDefinition) {
if (err) {
if (err.message == 'Unable to describe task definition.'){
process.exit( " we shouldn't get in here unless we're standing up a new ECS account\nif so, create and push a hello-world ecr docker image\nand then use the console to create a hello-world task definition pointing to the hello-world ecr image");
} else {
process.exit(' exiting due to unhandled error: ', err);
}
} else  {   
// register the hello-world task definition for the new service
// replace some values
//
//* UnexpectedParameter: Unexpected key 'taskDefinitionArn' found in params
//* UnexpectedParameter: Unexpected key 'revision' found in params
//* UnexpectedParameter: Unexpected key 'status' found in params
//* UnexpectedParameter: Unexpected key 'requiresAttributes' found in params
//* UnexpectedParameter: Unexpected key 'compatibilities' found in params
//
helloWorldTaskDefinition = helloWorldTaskDefinition.taskDefinition;
helloWorldTaskDefinition.family = serviceName+'-poc';
delete helloWorldTaskDefinition.taskDefinitionArn;
delete helloWorldTaskDefinition.revision;
delete helloWorldTaskDefinition.status;
delete helloWorldTaskDefinition.requiresAttributes;
delete helloWorldTaskDefinition.compatibilities;
helloWorldTaskDefinition.cpu = '1024';
// console.log("registering task def with params: ", params);
ecs.registerTaskDefinition(helloWorldTaskDefinition,  function(err, registerTaskDefinitionResponse) {
if (err){
console.log('err: ',err);
} else {
console.log('data: ', registerTaskDefinitionResponse);
}
});
}
});
 **/
