'use strict';
const args = require('yargs').argv;

var requiredArgs = [];

// check for the required arguments or for the --help flag, print usage statement and exit if missing required args or --help is passed 
const usageString = '\nUsage: node add_task_definitions.js \nExample:  node add_task_defninitions.js \n';
requiredArgs.forEach(function(requiredArgName){
    if (!args[requiredArgName] || args.help){
        console.log(usageString);
        process.exit();
    }   
});

const fs = require('fs');
const AWS = require('aws-sdk');

// for some reason the region isn't getting picked up from the global config, set it here
AWS.config.update({region:'us-west-2'});
const ssm = new AWS.SSM();

var parameterStoreStrings = {};
fs.readFile('./parameterStoreStrings.json', 'utf8', function(err, file){

    try{
        parameterStoreStrings = JSON.parse(file);
    } catch(err){
        console.log("err: ", err);

    }
    var keys = Object.getOwnPropertyNames(parameterStoreStrings);

    keys.forEach(function(key){
        console.log('key: ', key );

        ssm.getParameter( {Name: key} , function(err, data) {
            if (err) {
                if (err.code == 'ParameterNotFound'){
                    console.log('ParameterNotFound, put it into the Paramter Store');

                    if (true){
console.log('got --dry-run, parameter ' +key+);
                    } else {
                        ssm.putParameter( {Name: key, Value: parameterStoreStrings[key], Type: 'String'} , function(err, data) {
                            if (err){
                                console.log('err in putParameter: ', err);
                            } else {
                                console.log('success putting parameter: ', key);
                                console.log('with data: ', data);
                            }
                        });
                    }
                } else {
                    console.log("unhandled error, code: ", err.code);
                    console.log(err, err.stack); // an error occurred
                }
            } else  {
                if (data.Parameter.Type == 'String' ){
                    console.log("'" +data.Parameter.Name +"': '" + data.Parameter.Value + "',");
                    if (data.Parameter.Value !==  parameterStoreStrings[key]){
                        console.log('existing parameter ' +key+ ' has been updated, pushing new value: ',  parameterStoreStrings[key]);
                        ssm.putParameter( {Name: key, Value: parameterStoreStrings[key], Type: 'String'} , function(err, data) {
                            if (err){
                                console.log('err in putParameter: ', err);
                            } else {
                                console.log('success putting parameter: ', key);
                                console.log('with data: ', data);
                            }
                        });
                    } else {

                    }
                } 
            }
        });

    })
})

