'use strict';
const args = require('yargs').argv;
if (args['debug']) console.log("Got args: ", args);

// specify the required arguments
var requiredArgs = ["path", "environment"];

const usageString = `\n
Usage: node put_parameters.js --path <path to json file with Key: Value> --environment <target environment> --service <service name> \n
performs a putParameter operation for every key:value in the provided parameter file.  Prepends the path /CI/MS/<environment>/<service>/<key> \n
Example:  node put_parameters.js --path ./parameterStoreStrings.json --environment Dev --service Notification\n
will loop over every entry in ./parameterStoreStrings.json and perform a put operation at the path /CI/MS/Dev/Notification/<key> with the value parameterStoreStrings[key]\n
\n            --dry-run[optional]\tprint out the actions that would be performed but don't execute put operation
\n            --debug[optional]  \tprint debugging output`;

// check for the required arguments or for the --help flag, print usage statement and exit if missing required args or --help is passed 
requiredArgs.forEach(function(requiredArgName){
    if (!args[requiredArgName] || args.help){
        console.log(usageString);
        process.exit();
    }   
});

const fs = require('fs');
const AWS = require('aws-sdk');

// the region isn't getting picked up from the global config, set it here
AWS.config.update({region:'us-west-2'});
const ssm = new AWS.SSM();

var parameterStoreStrings = {};
fs.readFile(args['path'], 'utf8', function(err, file){

    try{
        parameterStoreStrings = JSON.parse(file);
    } catch(err){
        // if we can't parse the file then exit
        console.log("err: ", err);
        exit();
    }

    const keys = Object.getOwnPropertyNames(parameterStoreStrings);

    // at this point we require an environment for all parameters, if that changes then we'll have to do some refactoring
    let prefix = "/CI/MS/"+args['environment'];

    // if we weren't passed a service then we're doing shared params
    // if we were, then include the service in the path
    if (args['service']){
        prefix = prefix+"/"+args['service'];
    }

    // loop over the object keys and verify that they ALL have a value before proceeding with any param store updates
    keys.forEach(function(key){

        if (!parameterStoreStrings[key]['Value']){
            console.log("A Value is required for every parameter, please provide a Value for key: ", key);
            process.exit();
        }
    })

    // loop over the object keys, these will be the param store Names
    keys.forEach(function(key){

        if (args['debug']) console.log('key:value ', key+": "+parameterStoreStrings[key]['Value'] );
        let paramPath = prefix +"/"+ key;

        if (args['dry-run']){
            console.log("--dry-run selected\n\tIf not, would be performing putParameter with key:value  " +paramPath+": "+  parameterStoreStrings[key]['Value']);
        } else {
            let params  = {"Name": paramPath};
            params.Type = "String";
            params.Overwrite = true;
            params.Value = parameterStoreStrings[key]['Value'];

            // Description is optional, add it if we have it
            if (parameterStoreStrings[key]['Description']){
                params.Description = parameterStoreStrings[key]['Description'];
            }
            if (args['debug']) console.log('into the ssm.putParameter block with params: ', params);
            ssm.putParameter( params , function(err, data) {
                if (err) {
                    console.log(err, err.stack); // an error occurred
                } 
            });
        }
    })
})

