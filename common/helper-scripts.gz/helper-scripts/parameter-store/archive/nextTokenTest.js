const AWS = require('aws-sdk');
const util = require('util');

// the region isn't getting picked up from the global config, set it here
AWS.config.update({region:'us-west-2'});
const ec2 = new AWS.EC2();
const ssm = new AWS.SSM();
//

let count = 0;
let parameters = [];
function getParameters(params) {
    
    ssm.getParametersByPath(params, function(err, data) {
        if (err) {
            console.log(err, err.stack);
        }else     {
            parameters = parameters.concat(data.Parameters);
            if (data.NextToken) {
                params.NextToken = data.NextToken;
                getParameters(params);
            } else {
                // you have the whole response, do stuff with it
                console.log(util.inspect(parameters, false, null));
            }  
        }
    });
}


getParameters({Path:"/CI/MS/test2", Recursive: true});
