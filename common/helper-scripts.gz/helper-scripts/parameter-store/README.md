This README describes the helper-scripts/parameter-store scripts

These scripts were originally written to copy all the parameter store entries from the /CI/MS/dev/ * path to /CI/MS/test2/
Initial proof of concept and different iterations of the scripts can be found in the archive directory 

This is the usual flow of events:
  - write_terraform_parameter_store_files.js takes --from-path and --to-path parameters
    - it then reads the aws parameter store parameters in --from-path and writes terraform resource files with the --from-path replaced with --to-path
    - the terraform resource files are written to the parameterStoreFiles/<to-path> directory (if the directory doesn't exist then you'll have to create it)
    - running 'terraform apply' in the parameterStoreFiles/<to-path> directory will trigger terraform to create the parameters
      - Note that you have to assume the build server role for the desired account (i.e. ci-WebTFSBuildRole) before running 'terraform apply' 

The sequence of commands might look like this:
  # assume the role for the --from-path aws account
  - python /data/code/helper-scripts/swap-profile/swap-profile.py ci-WebTFSBuildRole-dev --assume
  # create the directory to hold the terraform resource file output
  - mkdir parameterStoreFiles/test
  # run the node script to create the terraform resource files
  - node write_terraform_parameter_store_files.js --fromPath 'dev' --toPath 'test'
  # cd into the directory where the terraform resource files were written
  - cd parameterStoreFiles/test
  # assume the role for the --to-path aws account
  - python /data/code/helper-scripts/swap-profile/swap-profile.py ci-WebTFSBuildRole-test --assume
  - terraform apply


