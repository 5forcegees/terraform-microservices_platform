'use strict';
const args = require('yargs').argv;
if (args['debug']) console.log("Got args: ", args);

// specify the required arguments
var requiredArgs = ["fromPath", "toPath"];

const usageString = `\n
Usage: node write_terraform_parameter_store_files.js --fromPath <parameter store path you want to recurse down below /CI/MS/<fromPath> > --toPath <target path to insert into parameter store into /CI/MS/<toPath> > \n
creates terraform resource declaration file for each parameter found in /CI/MS/<fromPath> \n
Example:  node write_terraform_parameter_store_files.js --fromPath 'test2' --toPath 'test' \n
\n            --fromPath[required]  \tPath to retrieve value from /CI/MS/<fromPath>
\n            --toPath[required]  \tPath to place value in /CI/MS/<toPath>`;

// check for the required arguments or for the --help flag, print usage statement and exit if missing required args or --help is passed 
requiredArgs.forEach(function(requiredArgName){
    if (!args[requiredArgName] || args.help){
        console.log(usageString);
        process.exit();
    }   
});

const AWS = require('aws-sdk');
const util = require('util');
const fs = require('fs');
const fromPath = args['fromPath'];
const toPath = args['toPath'];

// the region isn't getting picked up from the global config, set it here
AWS.config.update({region:'us-west-2'});
const ec2 = new AWS.EC2();
const ssm = new AWS.SSM();

// set up the file path
const fileRoot = "./parameterStoreFiles" + "/" + toPath;
const providerFileString = 'provider "aws" {\n  region = "us-west-2" \n}';

// put the provider file in the dir
fs.writeFile(fileRoot+"/provider.config.tf" , providerFileString, 'utf8', function(err, result){
    if (err){
        console.log("err: ", err);
    }
    if (result){
        console.log("result: ", result);
    }
});

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};
let count = 0;
let parameters = [];
function getParameters(params) {

    ssm.getParametersByPath(params, function(err, data) {
        if (err) {
            console.log(err, err.stack);
        }else     {
            parameters = parameters.concat(data.Parameters);
            if (data.NextToken) {
                params.NextToken = data.NextToken;
                getParameters(params);
            } else {
                // you have the whole response, do stuff with it
                // console.log(util.inspect(parameters, false, null));


                parameters.forEach(function(parameter){

//                    console.log("parameter: ", parameter);   
//                    if (parameter.Type === "String"){
                      console.log("Got String parameter: ", parameter);

                        // get the last part of the name to use in the file path
                        let parameterArr = parameter.Name.split("/");
                        let parameterLastName = parameterArr[parameterArr.length - 2] +"_"+ parameterArr[parameterArr.length - 1];

                        let filePath = fileRoot+"/"+parameterLastName+".tf";

                        // escape all the "
                        let parameterValue = parameter.Value.replaceAll('"', '\\"' );

                        // update the name to the toPath
                        let newPath = parameter.Name.replaceAll('/CI/MS/'+fromPath+'/', '/CI/MS/'+toPath+'/' );

                        // put together the terraform file contents as a string
                        let fileString = "resource \"aws_ssm_parameter\" \""+  parameterLastName +"\"  {\n    name = \"" + newPath + "\"\n    type = \"" + parameter.Type + "\"\n    value= \"" +parameterValue+ "\"\n}";
                        console.log(fileString + "\n");

                        // write the file
                        // the writeFile here is sometimes printing some extra nonsense in the output fileString ( like "}bsystem.v02", etc, I'm not sure where that's coming from )
                        // since it only happens in a small number of cases I'm just manually fixing those and moving on.  
                        // Be aware, you'll have to do some cleanup if you use this
                        fs.writeFile(filePath, fileString, 'utf8', function(err, result){
                            if (err){
                                console.log("err: ", err);
                            }
                            if (result){
                                console.log("result: ", result);
                            }
                        });
                    //} else {
//                        console.log("skipping parameter "+parameter.Name+" because we only want Strings.  This one's a " + parameter.Type);
                    //}
                }); 
            }  
        }
    });
}

getParameters({Path:"/CI/MS/"+fromPath, Recursive: true, WithDecryption: true});
