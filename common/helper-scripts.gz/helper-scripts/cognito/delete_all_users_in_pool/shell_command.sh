# remove the current userData files
rm -rf userData/*

# regenerate the userData files to get the current list, uses the WebAccount cognito user pool
# puts the users in files that contain 20 users each to prevent hitting the AWS request limit
node write_cognito_users_to_disk.js --userPoolId 'us-west-2_MQjUTtogs'

# loop over the userData files and delete the users from the provided pool
# the loop divides up the userData files based on the numbers (20 will loop over userData/userData_20* files, 21 will loop over userData/userData_21* files, etc)
# deletes the file when it's done
# update the UserPoolId to whatever the target pool and client are
for i in $(echo 1 2 3 4 5 6 7 8 9 0 ) ; do python /data/code/helper-scripts/swap-profile/swap-profile.py AWS-WebTFSBuildRole --assume &&  for q in $(ls userData/userData_$i*) ; do for r in $(cat $q) ; do aws cognito-idp admin-delete-user  --user-pool-id us-west-2_MQjUTtogs --username $r && rm $q   ;done ; done ; done

