'use strict';
const args = require('yargs').argv;

var requiredArgs = ["path", 'UserPoolId', "ClientId"];

// check for the required arguments or for the --help flag, print usage statement and exit if missing required args or --help is passed
const usageString = '\nUsage: node add_task_definitions.js \nExample:  node add_task_defninitions.js \n';
requiredArgs.forEach(function(requiredArgName){
    if (!args[requiredArgName] || args.help){
        console.log(usageString);
        console.log("Required Args: ", requiredArgs);
        console.log("Received Args: ", args);
        process.exit();
    }
});

console.log("path: ", args['path']);
const AWS = require('aws-sdk');
const util = require('util');
const fs = require('fs');

// the region isn't getting picked up from the global config, set it here
AWS.config.update({region:'us-west-2'});
const ec2 = new AWS.EC2();
const cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();

//

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};
let count = 0;
let users = [];
let files = [ args['path'] ]
function putUsers() {
    let groupCount = 0;
    files.forEach(function(path){

        fs.readFile(path, "utf8", function(error, data) {
            if (error) {
                console.error("read error:  " + error.message);
            } else {
                let usersArray;
                try{
                    usersArray = JSON.parse(data);
                }catch(err){
                    console.log("caught error: ", err);
                }
                usersArray.forEach(function(user){
                    // hundreds of async requests caused an error with the aws calls, exceeded requests.  slowing it down with a sleep to prevent error
                    sleep( (100*count++) , user, function(user){
                        let pushUser = {};
                        pushUser.UserPoolId = args['UserPoolId'];
                        pushUser.Username = user.Username;
                        pushUser.MessageAction = "SUPPRESS";
                        pushUser.TemporaryPassword = "admin1P@ssword";

                        let attributes = [];
                        user.Attributes.forEach(function(attributeObject){
                            if (attributeObject.Name !== "sub"){
                                attributes.push(attributeObject);
                            }
                        })

                        pushUser.UserAttributes = attributes;

                        cognitoidentityserviceprovider.adminCreateUser(pushUser, function(err, data) {
                            if (err) {
                                console.log(err, err.stack); // an error occurred
                            } else {

                                let adminInitiateAuthParams = {
                                    AuthFlow: 'ADMIN_NO_SRP_AUTH', 
                                    ClientId: args['ClientId'], 
                                    UserPoolId: pushUser.UserPoolId,
                                    AuthParameters: {
                                        'USERNAME': pushUser.Username,
                                        'PASSWORD': pushUser.TemporaryPassword
                                    }

                                };

                                //console.log("starting adminInitiateAuth with params: ", adminInitiateAuthParams);
                                cognitoidentityserviceprovider.adminInitiateAuth( adminInitiateAuthParams , function(err, data) {
                                    if (err) {
                                        console.log(err, err.stack);
                                    } else  {
                                        //console.log("success: ",util.inspect(data, false, null));

                                        let adminResponseParams = {
                                            ChallengeName: data.ChallengeName, 
                                            ClientId: adminInitiateAuthParams.ClientId, 
                                            UserPoolId: pushUser.UserPoolId,
                                            Session: data.Session,
                                            ChallengeResponses: {
                                                NEW_PASSWORD: pushUser.TemporaryPassword,
                                                USERNAME: data.ChallengeParameters.USER_ID_FOR_SRP
                                            }

                                        };
                                        //console.log("starting adminRespondToAuthChallenge with params: ", adminResponseParams);
                                        cognitoidentityserviceprovider.adminRespondToAuthChallenge(adminResponseParams, function(err, data) {
                                            if (err){
                                                console.log(err, err.stack); // an error occurred
                                            } else  {
                                                console.log("success with username: ", adminResponseParams.ChallengeResponses.USERNAME );           // successful response
                                            } 
                                        });
                                    }
                                });
                            }
                        });

                        /**
                          var params = {
                          AuthFlow: USER_SRP_AUTH | REFRESH_TOKEN_AUTH | REFRESH_TOKEN | CUSTOM_AUTH | ADMIN_NO_SRP_AUTH | USER_PASSWORD_AUTH, /* required 
                          ClientId: 'STRING_VALUE', /* required 
                          UserPoolId: 'STRING_VALUE', /* required 
                          };
                         **/
                        /**
                          var params = {
                          ChallengeName: SMS_MFA | SOFTWARE_TOKEN_MFA | SELECT_MFA_TYPE | MFA_SETUP | PASSWORD_VERIFIER | CUSTOM_CHALLENGE | DEVICE_SRP_AUTH | DEVICE_PASSWORD_VERIFIER | ADMIN_NO_SRP_AUTH | NEW_PASSWORD_REQUIRED, /* required 
                          ClientId: 'STRING_VALUE', /* required 
                          UserPoolId: 'STRING_VALUE', /* required 
                          };
                         **/

                        /**
                          cognitoidentityserviceprovider.adminConfirmSignUp({UserPoolId: pushUser.UserPoolId, Username: pushUser.Username}, function(err, data) {
                          if (err) console.log(err, err.stack); // an error occurred
                          else     console.log("adminConfirmSignUp data: ",util.inspect(data, false, null));           // successful response
                          });
                         **/
                    });
                })
            }
        });
    });

}

function sleep(time, user, callback) {
    var stop = new Date().getTime();
    while(new Date().getTime() < stop + time) {
        ;
    }
    callback(user);
}

putUsers();


