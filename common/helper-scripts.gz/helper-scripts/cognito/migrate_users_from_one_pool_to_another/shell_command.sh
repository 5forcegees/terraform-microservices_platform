# remove the current userData files
rm -rf userData/*

# make sure the access token for the required role is fresh so it doesn't expire during the run
python /data/code/helper-scripts/swap-profile/swap-profile.py AWS-WebTFSBuildRole --assume

# regenerate the userData files to get the current list, uses the WebAccount cognito user pool
# puts the users in files that contain 20 users each to prevent hitting the AWS request limit
node write_cognito_users_to_disk.js --userPoolId 'us-west-2_tvx9jhjOp'

# loop over the userData files and put the users into the provided pool
# sleep 1 second in between each file to ensure that the AWS request limit isn't exceeded
# update the UserPoolId and ClientId to whatever the target pool and client are
for i in $( ls userData/ ); do echo $i && node put_cognito_users_from_disk.js --path "userData/$i" --UserPoolId "us-west-2_rVTE1uJzJ" --ClientId "7sutptl2mrcnom1huuvhku34ln"   && sleep 1; done 
