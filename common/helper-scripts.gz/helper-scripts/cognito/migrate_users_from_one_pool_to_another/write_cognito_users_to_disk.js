'use strict';
const args = require('yargs').argv;

var requiredArgs = ['userPoolId'];

// check for the required arguments or for the --help flag, print usage statement and exit if missing required args or --help is passed
const usageString = '\nUsage: node write_cognito_users_to_disk.js --userPoolId <pool id>\nExample:  node write_cognito_users_to_disk.js  --userPoolId \'us-west-2_3N2q3Itha\' \n';
requiredArgs.forEach(function(requiredArgName){
      if (!args[requiredArgName] || args.help){
            console.log(usageString);
            console.log("Required Args: ", requiredArgs);
            console.log("Received Args: ", args);
            process.exit();
        }
  });


const AWS = require('aws-sdk');
const util = require('util');
const fs = require('fs');

// the region isn't getting picked up from the global config, set it here
AWS.config.update({region:'us-west-2'});
const ec2 = new AWS.EC2();
const cognitoisp = new AWS.CognitoIdentityServiceProvider();

//

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};
let count = 1;
let users = [];
function getUsers(params) {

    cognitoisp.listUsers(params, function(err, data) {
        if (err) {
            console.log(err, err.stack);
        } else  {
            //console.log("got data: ", data);
            users = users.concat(data.Users);

            // recurse into the function until we don't get a PaginationToken
            if (data.PaginationToken ) {
                params.PaginationToken = data.PaginationToken;
                getUsers(params);
            } else {
                // you have the whole response, do stuff with it
                //                console.log(util.inspect(users, false, null));
                console.log("# Users: ",users.length);

                users.forEach(function(user){

                    let filePath = "./userData/userData_" + count++;

                    fs.writeFile(filePath, JSON.stringify([user]), 'utf8', function(err, result){
                        if (err){
                            console.log("err: ", err);
                        }
                        if (result){
                            console.log("result: ", result);
                        }
                    });
                })
            }
        }
    });
}

getUsers({UserPoolId:"us-west-2_Zfg0fUSpS"});





/**
 *user:  { 
 Username: 'testuserpadev2',
 Attributes:
 [ { Name: 'sub', Value: '12b2dd14-ef8b-428b-ad48-4d30d758b00b' },
 { Name: 'email_verified', Value: 'false' },
 { Name: 'custom:bp', Value: '1201162132' },
 { Name: 'email', Value: 'testuserpaDev2@test.com' } ],

 UserCreateDate: 2018-03-16T21:57:21.536Z,
 UserLastModifiedDate: 2018-03-16T21:57:21.536Z,
 Enabled: true,
 UserStatus: 'CONFIRMED' }


 var params = {
 UserPoolId: 'STRING_VALUE', /* required 
 Username: 'STRING_VALUE', /* required 
 DesiredDeliveryMediums: [
 SMS | EMAIL,
/* more items 
],
ForceAliasCreation: true || false,
MessageAction: RESEND | SUPPRESS,
TemporaryPassword: 'STRING_VALUE',
UserAttributes: [
 * **/

/**
// get the last part of the name to use in the file path
let userArr = user.Name.split("/");
let userLastName = userArr[userArr.length - 2] +"."+ userArr[userArr.length - 1];

// set up the file path
let filePath = "./userStoreFiles";

// if it has /Dev/ then write that to an environment specific folder
//                        if (user.Name.match("/Dev/")){
//                        just add the /Dev to the path every time for the initial seed
filePath = filePath + "/Dev"
//                      }
filePath = filePath+"/"+userLastName+".tf";

// escape all the "
let userValue = user.Value.replaceAll('"', '\\"' );

// put together the file contents as a string
let fileString = "resource \"aws_ssm_user\" \""+  userLastName +"\"  {\n    name = \"" + user.Name + "\"\n    type = \"" + user.Type + "\"\n    value= \"" +userValue+ "\"\n}";
console.log(fileString + "\n");

// write the file
// the writeFile here is sometimes printing some extra nonsense in the output fileString ( like "}bsystem.v02", etc, I'm not sure where that's coming from )
// since it only happens in a small number of cases I'm just manually fixing those and moving on.  
// Be aware, you'll have to do some cleanup if you use this
fs.writeFile(filePath, fileString, 'utf8', function(err, result){
if (err){
console.log("err: ", err);
}
if (result){
console.log("result: ", result);
}
});
 **/
